
using System;

namespace DsmGen.ApplicationCore.Enumerated.Dominio_dsm
{
public enum Talla_artEnum { Talla_35=1, Talla_36=2, Talla_37=3, Talla_38=4, Talla_39=5, Talla_40=6, Talla_41=7, Talla_42=8, Talla_43=9, Talla_44=10, Talla_45=11 };
}
