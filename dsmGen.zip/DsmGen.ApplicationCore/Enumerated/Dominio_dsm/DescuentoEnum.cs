
using System;

namespace DsmGen.ApplicationCore.Enumerated.Dominio_dsm
{
public enum DescuentoEnum { gastos_envio=1, diez=2, veinte=3, treinta=4 };
}
