
using System;

namespace DsmGen.ApplicationCore.Enumerated.Dominio_dsm
{
public enum EstadoPedidoEnum { pendiente=1, enviado=2, recibido=3, rechazado=4 };
}
