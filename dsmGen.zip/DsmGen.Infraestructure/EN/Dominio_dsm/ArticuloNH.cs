
using System;
using DsmGen.ApplicationCore.EN.Dominio_dsm;
namespace DsmGen.Infraestructure.EN.Dominio_dsm
{
public partial class ArticuloNH : ArticuloEN {
public ArticuloNH ()
{
}

public ArticuloNH (ArticuloEN dto) : base (dto)
{
}
}
}
