
using System;
using DsmGen.ApplicationCore.EN.Dominio_dsm;
namespace DsmGen.Infraestructure.EN.Dominio_dsm
{
public partial class UsuarioNH : UsuarioEN {
public UsuarioNH ()
{
}

public UsuarioNH (UsuarioEN dto) : base (dto)
{
}
}
}
