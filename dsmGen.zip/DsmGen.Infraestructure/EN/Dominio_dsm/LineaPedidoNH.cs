
using System;
using DsmGen.ApplicationCore.EN.Dominio_dsm;
namespace DsmGen.Infraestructure.EN.Dominio_dsm
{
public partial class LineaPedidoNH : LineaPedidoEN {
public LineaPedidoNH ()
{
}

public LineaPedidoNH (LineaPedidoEN dto) : base (dto)
{
}
}
}
