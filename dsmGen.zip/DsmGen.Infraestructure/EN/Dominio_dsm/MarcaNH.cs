
using System;
using DsmGen.ApplicationCore.EN.Dominio_dsm;
namespace DsmGen.Infraestructure.EN.Dominio_dsm
{
public partial class MarcaNH : MarcaEN {
public MarcaNH ()
{
}

public MarcaNH (MarcaEN dto) : base (dto)
{
}
}
}
