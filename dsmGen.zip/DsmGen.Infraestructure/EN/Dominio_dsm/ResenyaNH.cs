
using System;
using DsmGen.ApplicationCore.EN.Dominio_dsm;
namespace DsmGen.Infraestructure.EN.Dominio_dsm
{
public partial class ResenyaNH : ResenyaEN {
public ResenyaNH ()
{
}

public ResenyaNH (ResenyaEN dto) : base (dto)
{
}
}
}
