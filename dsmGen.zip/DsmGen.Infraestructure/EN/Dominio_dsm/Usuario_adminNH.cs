
using System;
using DsmGen.ApplicationCore.EN.Dominio_dsm;
namespace DsmGen.Infraestructure.EN.Dominio_dsm
{
public partial class Usuario_adminNH : Usuario_adminEN {
public Usuario_adminNH ()
{
}

public Usuario_adminNH (Usuario_adminEN dto) : base (dto)
{
}
}
}
