
using System;
using DsmGen.ApplicationCore.EN.Dominio_dsm;
namespace DsmGen.Infraestructure.EN.Dominio_dsm
{
public partial class FotoNH : FotoEN {
public FotoNH ()
{
}

public FotoNH (FotoEN dto) : base (dto)
{
}
}
}
