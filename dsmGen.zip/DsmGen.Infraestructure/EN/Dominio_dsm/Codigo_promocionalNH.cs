
using System;
using DsmGen.ApplicationCore.EN.Dominio_dsm;
namespace DsmGen.Infraestructure.EN.Dominio_dsm
{
public partial class Codigo_promocionalNH : Codigo_promocionalEN {
public Codigo_promocionalNH ()
{
}

public Codigo_promocionalNH (Codigo_promocionalEN dto) : base (dto)
{
}
}
}
